"""
new Env(易班自动签到)
cron: 59 20 * * *
"""

import os
import sys
import threading
import time

try:
    import requests
except ModuleNotFoundError:
    print("缺少依赖! 请安装依赖！")


class ServerChan:
    def __init__(self, title: str, token: str) -> None:
        self.title = title
        self.token = token
        self.msgs = ""

    def send_msg(self, token="", msg=""):
        if msg == "":
            msg = self.msgs
        if token == "" and self.token == "":
            return self
        if token == "":
            token = self.token
        requests.get(
            f"https://sctapi.ftqq.com/{token}.send",
            params={"title": self.title, "desp": msg},
            timeout=5,
        )
        self.msgs=''
        return self

    def log(self, msg=""):
        if msg == "":
            return self
        print(msg)
        if self.msgs == "":
            self.msgs = msg
        else:
            self.msgs += f"\n{msg}"
        return self

from yiban import Yiban

count = 3


def start_sign(user: dict):
    server_chan = ServerChan("易班签到详情", user["SendKey"])
    for i in range(count):
        yb = Yiban(user["Phone"], user["PassWord"])
        try:
            time_range = yb.task_feedback.get_sign_task()
        except Exception as e:
            # 一般是登录失败或登录超时
            print(e)
            print(f"{user['Phone']}出现错误, 尝试重新启动流程({i + 1}/{count})")
            time.sleep(2)
            # 重新进行登录操作
            continue
        while not time_range["StartTime"] < time.time() < time_range["EndTime"]:
            time.sleep(1)
        back = yb.submit_sign_feedback(user["Address"])
        server_chan.log(f'{user["Phone"]}: {back}').send_msg()
        return
    server_chan.log(f'{user["Phone"]}重试机会使用完').send_msg()

